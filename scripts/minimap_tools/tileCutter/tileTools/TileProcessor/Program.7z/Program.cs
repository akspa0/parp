using System;
using System.Collections.Generic;
using System.CommandLine;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TileProcessor
{
    class Program
    {
        static async Task<int> Main(string[] args)
        {
            var rootCommand = new RootCommand("Process image tiles - cut and join with level support");

            // Create subcommands for cut and join operations
            var cutCommand = new Command("cut", "Cut an image into tiles");
            var joinCommand = new Command("join", "Join tiles into a single image");
            rootCommand.AddCommand(cutCommand);
            rootCommand.AddCommand(joinCommand);

            // Cut command options
            var inputImageOption = new Option<string>(
                "--input-image",
                "Path to the input image") { IsRequired = true };
            
            var outputFolderOption = new Option<string>(
                "--output-folder",
                "Path to the output folder") { IsRequired = true };
            
            var tileSizeOption = new Option<int>(
                "--tile-size",
                () => 128,
                "Size of each tile");
            
            var prefixOption = new Option<string>(
                "--prefix",
                "Prefix for the output filenames") { IsRequired = true };
            
            var noCombineOption = new Option<bool>(
                "--no-combine",
                () => false,
                "Do not combine the outputs at the end");
            
            var vcolOption = new Option<bool>(
                "--vcol",
                () => false,
                "Generate vertex color maps");

            var createKritaOption = new Option<bool>(
                "--create-krita",
                () => true,
                "Create a Krita file with all layers");

            cutCommand.AddOption(inputImageOption);
            cutCommand.AddOption(outputFolderOption);
            cutCommand.AddOption(tileSizeOption);
            cutCommand.AddOption(prefixOption);
            cutCommand.AddOption(noCombineOption);
            cutCommand.AddOption(vcolOption);
            cutCommand.AddOption(createKritaOption);

            cutCommand.SetHandler(async (inputImagePath, outputFolder, tileSize, prefix, noCombine, vcol, createKrita) =>
            {
                await TileCutter.ProcessImage(inputImagePath, outputFolder, tileSize, prefix, !noCombine, vcol, createKrita);
            }, 
            inputImageOption, outputFolderOption, tileSizeOption, prefixOption, noCombineOption, vcolOption, createKritaOption);

            // Join command options
            var inputFolderOption = new Option<string>(
                "--input-folder",
                "Path to the folder containing image tiles") { IsRequired = true };
            
            var outputImageOption = new Option<string>(
                "--output-image",
                "Path to save the output image") { IsRequired = true };
            
            var joinTileSizeOption = new Option<int>(
                "--tile-size",
                () => 257,
                "Size of each tile");

            var includeAlphaLayersOption = new Option<bool>(
                "--include-alpha",
                () => true,
                "Include alpha layers in the join process");

            joinCommand.AddOption(inputFolderOption);
            joinCommand.AddOption(outputImageOption);
            joinCommand.AddOption(joinTileSizeOption);
            joinCommand.AddOption(createKritaOption);
            joinCommand.AddOption(includeAlphaLayersOption);

            joinCommand.SetHandler(async (inputFolder, outputImage, tileSize, createKrita, includeAlpha) =>
            {
                await TileJoiner.StitchTiles(inputFolder, tileSize, outputImage, createKrita, includeAlpha);
            },
            inputFolderOption, outputImageOption, joinTileSizeOption, createKritaOption, includeAlphaLayersOption);

            return await rootCommand.InvokeAsync(args);
        }
    }

    public static class TileJoiner
    {
        // CHANGE HERE: Changed "_level" to "_layer" in both regex patterns
        private static readonly Regex TilePattern = new Regex(@"_(\d+)_(\d+)((?:_layer\d+)?)\.png$", RegexOptions.Compiled);
        private static readonly Regex LevelPattern = new Regex(@"_layer([1-3])$", RegexOptions.Compiled);

        public static async Task StitchTiles(string inputFolder, int tileSize, string outputImagePath, bool createKrita, bool includeAlpha)
        {
            Console.WriteLine($"Joining tiles from folder: {inputFolder}");

            // Debug: List all files in the folder
            var allFilesInDirectory = Directory.GetFiles(inputFolder, "*.png");
            Console.WriteLine($"Found {allFilesInDirectory.Length} PNG files in folder:");
            foreach (var file in allFilesInDirectory.Take(10)) // Only show first 10 to avoid flooding console
            {
                Console.WriteLine($"  - {Path.GetFileName(file)}");
            }
            if (allFilesInDirectory.Length > 10)
            {
                Console.WriteLine($"  ... and {allFilesInDirectory.Length - 10} more files");
            }

            // Get a list of all image files in the input folder
            var allFiles = Directory.GetFiles(inputFolder, "*.png")
                .Select(path => new { Path = path, Filename = Path.GetFileName(path) })
                .ToList();

            // Filter out level files for base image
            var baseTileFiles = allFiles
                .Where(file => !LevelPattern.IsMatch(Path.GetFileNameWithoutExtension(file.Path)))
                .ToList();

            if (baseTileFiles.Count == 0)
            {
                Console.WriteLine("No base tile files found in the input folder.");
                return;
            }

            // Extract tile indices
            var tileIndices = new List<(int X, int Y, string Path)>();
            foreach (var file in baseTileFiles)
            {
                var match = TilePattern.Match(file.Filename);
                if (match.Success)
                {
                    int x = int.Parse(match.Groups[1].Value);
                    int y = int.Parse(match.Groups[2].Value);
                    tileIndices.Add((x, y, file.Path));
                }
                else
                {
                    Console.WriteLine($"File didn't match pattern: {file.Filename}");
                }
            }

            if (tileIndices.Count == 0)
            {
                Console.WriteLine("No tiles with valid naming pattern found.");
                return;
            }

            Console.WriteLine($"Found {tileIndices.Count} valid base tiles.");

            // Determine image dimensions
            int maxXIndex = tileIndices.Max(t => t.X);
            int maxYIndex = tileIndices.Max(t => t.Y);
            int newImageWidth = (maxXIndex + 1) * tileSize;
            int newImageHeight = (maxYIndex + 1) * tileSize;

            Console.WriteLine($"New image dimensions: {newImageWidth} x {newImageHeight}");

            // Create the stitched image
            using var newImage = new Bitmap(newImageWidth, newImageHeight);
            using var mainGraphics = Graphics.FromImage(newImage);
            
            // Fill with white background
            mainGraphics.Clear(Color.White);

            // Paste each tile
            foreach (var (x, y, path) in tileIndices)
            {
                using var tile = new Bitmap(path);
                int posX = x * tileSize;
                int posY = y * tileSize;
                mainGraphics.DrawImage(tile, posX, posY);
                Console.WriteLine($"Pasted tile at: ({posX}, {posY})");
            }

            // Save the stitched image
            newImage.Save(outputImagePath, ImageFormat.Png);
            Console.WriteLine($"Stitched image saved at: {outputImagePath}");

            // Process alpha layers if requested
            if (includeAlpha)
            {
                var levelImages = new Dictionary<int, Bitmap>();
                var levelGraphics = new Dictionary<int, Graphics>();
                
                // Initialize level images
                for (int level = 1; level <= 3; level++)
                {
                    levelImages[level] = new Bitmap(newImageWidth, newImageHeight);
                    levelGraphics[level] = Graphics.FromImage(levelImages[level]);
                    levelGraphics[level].Clear(Color.White);
                }

                // Get all level files
                var levelFiles = allFiles
                    .Where(file => LevelPattern.IsMatch(Path.GetFileNameWithoutExtension(file.Path)))
                    .ToList();

                Console.WriteLine($"Found {levelFiles.Count} layer files.");

                // Process each level file
                foreach (var file in levelFiles)
                {
                    var filenameWithoutExt = Path.GetFileNameWithoutExtension(file.Path);
                    var tileMatch = TilePattern.Match(file.Filename);
                    var levelMatch = LevelPattern.Match(filenameWithoutExt);
                    
                    if (tileMatch.Success && levelMatch.Success)
                    {
                        int x = int.Parse(tileMatch.Groups[1].Value);
                        int y = int.Parse(tileMatch.Groups[2].Value);
                        int level = int.Parse(levelMatch.Groups[1].Value);
                        
                        if (level >= 1 && level <= 3)
                        {
                            using var tile = new Bitmap(file.Path);
                            int posX = x * tileSize;
                            int posY = y * tileSize;
                            levelGraphics[level].DrawImage(tile, posX, posY);
                            Console.WriteLine($"Pasted layer {level} tile at: ({posX}, {posY})");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Layer file didn't match expected pattern: {file.Filename}");
                    }
                }

                // Save level images
                string baseOutputPath = Path.Combine(
                    Path.GetDirectoryName(outputImagePath) ?? "",
                    Path.GetFileNameWithoutExtension(outputImagePath));
                
                for (int level = 1; level <= 3; level++)
                {
                    // CHANGE HERE: Changed "_level" to "_layer"
                    string levelOutputPath = $"{baseOutputPath}_layer{level}.png";
                    levelImages[level].Save(levelOutputPath, ImageFormat.Png);
                    Console.WriteLine($"Layer {level} image saved at: {levelOutputPath}");
                }

                // Create Krita file if requested
                if (createKrita)
                {
                    await CreateKritaFile(outputImagePath, levelImages);
                }

                // Dispose level graphics
                foreach (var graphics in levelGraphics.Values)
                {
                    graphics.Dispose();
                }
                
                // Dispose level images
                foreach (var image in levelImages.Values)
                {
                    image.Dispose();
                }
            }
        }

        private static async Task CreateKritaFile(string baseImagePath, Dictionary<int, Bitmap> levelImages)
        {
            string kritaFilePath = Path.Combine(
                Path.GetDirectoryName(baseImagePath) ?? "",
                $"{Path.GetFileNameWithoutExtension(baseImagePath)}.kra");

            var tempDir = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(tempDir);
            
            try
            {
                // Create Krita file structure
                Directory.CreateDirectory(Path.Combine(tempDir, "data"));
                Directory.CreateDirectory(Path.Combine(tempDir, "previews"));
                
                // Create mergedimage.png (main image)
                File.Copy(baseImagePath, Path.Combine(tempDir, "mergedimage.png"));
                
                // Copy layer images
                File.Copy(baseImagePath, Path.Combine(tempDir, "data", "layer1.png"));
                
                // Create alpha channel layers
                var layerInfo = new List<(int LayerNum, string Name, string Filename)>();
                layerInfo.Add((1, "Base Image", "layer1.png"));
                
                int layerIndex = 2;
                foreach (var kvp in levelImages)
                {
                    string levelFilename = $"layer{layerIndex}.png";
                    string colorChannel = kvp.Key == 1 ? "Red" : (kvp.Key == 2 ? "Green" : "Blue");
                    // CHANGE HERE: Kept "Alpha Channel", but changed level references
                    string levelName = $"Alpha Channel {colorChannel}";
                    
                    // Save the level image
                    string levelPath = Path.Combine(tempDir, "data", levelFilename);
                    kvp.Value.Save(levelPath, ImageFormat.Png);
                    
                    layerInfo.Add((layerIndex, levelName, levelFilename));
                    layerIndex++;
                }
                
                // Create maindoc.xml
                var documentXml = CreateKritaDocumentXml(levelImages[1].Width, levelImages[1].Height, layerInfo);
                await File.WriteAllTextAsync(Path.Combine(tempDir, "maindoc.xml"), documentXml);
                
                // Create mimetype file
                await File.WriteAllTextAsync(Path.Combine(tempDir, "mimetype"), "application/x-krita");
                
                // Create the Krita file
                ZipFile.CreateFromDirectory(tempDir, kritaFilePath);
                
                Console.WriteLine($"Krita file created at: {kritaFilePath}");
            }
            finally
            {
                // Clean up the temp directory
                if (Directory.Exists(tempDir))
                {
                    Directory.Delete(tempDir, true);
                }
            }
        }
        
        private static string CreateKritaDocumentXml(int width, int height, List<(int LayerNum, string Name, string Filename)> layerInfo)
        {
            var xml = new StringBuilder();
            xml.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            xml.AppendLine("<DOC xmlns=\"http://www.calligra.org/DTD/krita\">");
            xml.AppendLine($" <IMAGE width=\"{width}\" height=\"{height}\" colorspacename=\"RGBA\">");
            xml.AppendLine("  <LAYERS>");
            
            foreach (var layer in layerInfo)
            {
                xml.AppendLine($"   <LAYER name=\"{layer.Name}\" filename=\"{layer.Filename}\" visible=\"1\">");
                xml.AppendLine("   </LAYER>");
            }
            
            xml.AppendLine("  </LAYERS>");
            xml.AppendLine(" </IMAGE>");
            xml.AppendLine("</DOC>");
            
            return xml.ToString();
        }
    }

    public static class TileCutter
    {
        // CHANGE HERE: Changed "_level" to "_layer"
        private static readonly Regex LevelPattern = new Regex(@"_layer([1-3])$", RegexOptions.Compiled);

        public static async Task ProcessImage(string inputImagePath, string outputFolder, int tileSize, string prefix, 
            bool combine, bool vcol, bool createKrita)
        {
            Console.WriteLine($"Processing image: {inputImagePath}");
            
            // Ensure output directory exists
            Directory.CreateDirectory(outputFolder);

            // Group input files by their base name (without level)
            var inputFiles = Directory.GetFiles(Path.GetDirectoryName(inputImagePath) ?? ".", "*.png")
                .GroupBy(path => GetBaseFileName(path))
                .ToDictionary(g => g.Key, g => g.ToList());

            var mainImagePath = inputImagePath;
            if (inputFiles.ContainsKey(GetBaseFileName(inputImagePath)))
            {
                var fileGroup = inputFiles[GetBaseFileName(inputImagePath)];
                mainImagePath = fileGroup.FirstOrDefault(f => !IsLevelFile(f)) ?? inputImagePath;
            }

            using var originalImage = new Bitmap(mainImagePath);
            var nonBlankTiles = new List<(int Left, int Upper, int Right, int Lower, string BaseName)>();

            int numTilesX = originalImage.Width / tileSize;
            int numTilesY = originalImage.Height / tileSize;

            Console.WriteLine($"Number of tiles to process: {numTilesX} x {numTilesY}");

            // Process main image
            for (int y = 0; y < numTilesY; y++)
            {
                for (int x = 0; x < numTilesX; x++)
                {
                    int left = x * tileSize;
                    int upper = y * tileSize;
                    int right = left + tileSize;
                    int lower = upper + tileSize;

                    using var tile = new Bitmap(tileSize, tileSize);
                    using var tileGraphics = Graphics.FromImage(tile);
                    
                    // Copy the tile from the original image
                    tileGraphics.DrawImage(originalImage, 
                        new Rectangle(0, 0, tileSize, tileSize),
                        new Rectangle(left, upper, tileSize, tileSize),
                        GraphicsUnit.Pixel);

                    if (!IsBlankOrWhite(tile))
                    {
                        string suffix = vcol ? "_vcol" : "";
                        string tileName = $"{prefix}_{x}_{y}";
                        string tilePath = Path.Combine(outputFolder, $"{tileName}{suffix}.png");
                        
                        tile.Save(tilePath, ImageFormat.Png);
                        Console.WriteLine($"Processed tile {x}_{y} saved at: {tilePath}");
                        
                        nonBlankTiles.Add((left, upper, right, lower, tileName));
                        
                        // Process level files for the current tile
                        ProcessLevelFiles(inputFiles, left, upper, tileSize, outputFolder, 
                            $"{prefix}_{x}_{y}", vcol);
                    }
                }
            }

            if (combine)
            {
                var newImagePath = Path.Combine(outputFolder, $"{prefix}_new.png");
                BuildNewImage(originalImage, nonBlankTiles, tileSize, newImagePath);
                
                if (createKrita)
                {
                    await CreateKritaFile(outputFolder, prefix, nonBlankTiles);
                }

                ZipOutputFolder(inputImagePath, outputFolder, newImagePath);
            }
        }

        private static void ProcessLevelFiles(Dictionary<string, List<string>> inputFiles, 
            int left, int upper, int tileSize, string outputFolder, string tileBaseName, bool vcol)
        {
            foreach (var levelFileGroup in inputFiles.Values)
            {
                foreach (var levelFile in levelFileGroup.Where(IsLevelFile))
                {
                    var levelMatch = LevelPattern.Match(Path.GetFileNameWithoutExtension(levelFile));
                    if (levelMatch.Success)
                    {
                        string levelNum = levelMatch.Groups[1].Value;
                        using var levelImage = new Bitmap(levelFile);
                        using var levelTile = new Bitmap(tileSize, tileSize);
                        using var levelTileGraphics = Graphics.FromImage(levelTile);
                        
                        // Copy the tile from the level image
                        levelTileGraphics.DrawImage(levelImage, 
                            new Rectangle(0, 0, tileSize, tileSize),
                            new Rectangle(left, upper, tileSize, tileSize),
                            GraphicsUnit.Pixel);

                        if (!IsBlankOrWhite(levelTile))
                        {
                            string suffix = vcol ? "_vcol" : "";
                            // CHANGE HERE: Changed "_level" to "_layer"
                            string levelTilePath = Path.Combine(outputFolder, $"{tileBaseName}_layer{levelNum}{suffix}.png");
                            levelTile.Save(levelTilePath, ImageFormat.Png);
                            Console.WriteLine($"Processed layer{levelNum} tile saved at: {levelTilePath}");
                        }
                    }
                }
            }
        }

        private static bool IsLevelFile(string filePath)
        {
            return LevelPattern.IsMatch(Path.GetFileNameWithoutExtension(filePath));
        }

        private static string GetBaseFileName(string filePath)
        {
            string fileName = Path.GetFileNameWithoutExtension(filePath);
            return LevelPattern.Replace(fileName, "");
        }

        private static bool IsBlankOrWhite(Bitmap image)
        {
            const int threshold = 240;
            
            // Calculate mean pixel intensity
            long totalIntensity = 0;
            int pixelCount = 0;
            
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color color = image.GetPixel(x, y);
                    int intensity = (color.R + color.G + color.B) / 3;
                    totalIntensity += intensity;
                    pixelCount++;
                }
            }
            
            if (pixelCount == 0)
                return true;
                
            double meanIntensity = (double)totalIntensity / pixelCount;
            return meanIntensity >= threshold;
        }

        private static void BuildNewImage(Bitmap originalImage, List<(int Left, int Upper, int Right, int Lower, string BaseName)> nonBlankTiles, 
            int tileSize, string newImagePath)
        {
            if (nonBlankTiles.Count == 0)
            {
                Console.WriteLine("No non-blank tiles found. Cannot create new image.");
                return;
            }

            int minX = nonBlankTiles.Min(t => t.Left);
            int minY = nonBlankTiles.Min(t => t.Upper);
            int maxX = nonBlankTiles.Max(t => t.Right);
            int maxY = nonBlankTiles.Max(t => t.Lower);

            int newWidth = maxX - minX;
            int newHeight = maxY - minY;

            Console.WriteLine($"New image dimensions: {newWidth} x {newHeight}");

            using var newImage = new Bitmap(newWidth, newHeight);
            using var newImageGraphics = Graphics.FromImage(newImage);
            
            // Fill with white background
            newImageGraphics.Clear(Color.White);
            
            foreach (var tile in nonBlankTiles)
            {
                int destX = tile.Left - minX;
                int destY = tile.Upper - minY;
                
                Console.WriteLine($"Pasting tile at coordinates: ({destX}, {destY})");
                
                // Copy the tile from the original image
                newImageGraphics.DrawImage(originalImage, 
                    new Rectangle(destX, destY, tileSize, tileSize),
                    new Rectangle(tile.Left, tile.Upper, tileSize, tileSize),
                    GraphicsUnit.Pixel);
            }

            newImage.Save(newImagePath, ImageFormat.Png);
            Console.WriteLine($"New image saved at: {newImagePath}");
        }

        private static async Task CreateKritaFile(string outputFolder, string prefix, 
            List<(int Left, int Upper, int Right, int Lower, string BaseName)> nonBlankTiles)
        {
            var tempDir = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            Directory.CreateDirectory(tempDir);
            
            try
            {
                // Create Krita file structure
                Directory.CreateDirectory(Path.Combine(tempDir, "data"));
                Directory.CreateDirectory(Path.Combine(tempDir, "previews"));
                
                // Create mergedimage.png (main image)
                var mainImagePath = Path.Combine(outputFolder, $"{prefix}_new.png");
                if (File.Exists(mainImagePath))
                {
                    File.Copy(mainImagePath, Path.Combine(tempDir, "mergedimage.png"));
                }
                
                // Create maindoc.xml 
                var documentXml = CreateKritaDocumentXml(outputFolder, nonBlankTiles);
                await File.WriteAllTextAsync(Path.Combine(tempDir, "maindoc.xml"), documentXml);
                
                // Create mimetype file
                await File.WriteAllTextAsync(Path.Combine(tempDir, "mimetype"), "application/x-krita");
                
                // Copy all layer images
                var layerFolder = Path.Combine(tempDir, "data");
                
                // Main layer
                if (File.Exists(mainImagePath))
                {
                    File.Copy(mainImagePath, Path.Combine(layerFolder, "layer1.png"));
                }
                
                // Copy level layers
                int layerIndex = 2;
                foreach (var tile in nonBlankTiles)
                {
                    for (int level = 1; level <= 3; level++)
                    {
                        // CHANGE HERE: Changed "_level" to "_layer"
                        var levelPath = Path.Combine(outputFolder, $"{tile.BaseName}_layer{level}.png");
                        if (File.Exists(levelPath))
                        {
                            File.Copy(levelPath, Path.Combine(layerFolder, $"layer{layerIndex}.png"));
                            layerIndex++;
                        }
                    }
                }
                
                // Create the Krita file (which is a zip file)
                var kritaPath = Path.Combine(outputFolder, $"{prefix}.kra");
                ZipFile.CreateFromDirectory(tempDir, kritaPath);
                
                Console.WriteLine($"Krita file created at: {kritaPath}");
            }
            finally
            {
                // Clean up the temp directory
                if (Directory.Exists(tempDir))
                {
                    Directory.Delete(tempDir, true);
                }
            }
        }
        
        private static string CreateKritaDocumentXml(string outputFolder, 
            List<(int Left, int Upper, int Right, int Lower, string BaseName)> nonBlankTiles)
        {
            // This is a simplified XML structure for Krita
            // In a real implementation, this would need to be more complete
            string xml = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<DOC xmlns=""http://www.calligra.org/DTD/krita"">
 <IMAGE width=""$WIDTH"" height=""$HEIGHT"" colorspacename=""RGBA"">
  <LAYERS>
   <LAYER name=""Background"" filename=""layer1.png"" visible=""1"">
   </LAYER>
";
            // Add level layers
            int layerIndex = 2;
            foreach (var tile in nonBlankTiles)
            {
                for (int level = 1; level <= 3; level++)
                {
                    // CHANGE HERE: Changed "_level" to "_layer"
                    var levelPath = Path.Combine(outputFolder, $"{tile.BaseName}_layer{level}.png");
                    if (File.Exists(levelPath))
                    {
                        string colorChannel = level == 1 ? "Red" : (level == 2 ? "Green" : "Blue");
                        xml += $@"   <LAYER name=""{tile.BaseName} {colorChannel} Alpha"" filename=""layer{layerIndex}.png"" visible=""1"">
   </LAYER>
";
                        layerIndex++;
                    }
                }
            }

            xml += @"  </LAYERS>
 </IMAGE>
</DOC>";

            // Get image dimensions from the first file
            var mainImagePath = Path.Combine(outputFolder, $"{nonBlankTiles[0].BaseName}.png");
            if (File.Exists(mainImagePath))
            {
                using var img = new Bitmap(mainImagePath);
                xml = xml.Replace("$WIDTH", img.Width.ToString());
                xml = xml.Replace("$HEIGHT", img.Height.ToString());
            }
            else
            {
                xml = xml.Replace("$WIDTH", "1024");
                xml = xml.Replace("$HEIGHT", "1024");
            }

            return xml;
        }

        private static void ZipOutputFolder(string inputImagePath, string outputFolder, string newImagePath)
        {
            string inputFilename = Path.GetFileNameWithoutExtension(inputImagePath);
            string outputFolderName = Path.GetFileName(outputFolder);
            string zipFilename = $"{inputFilename}_{outputFolderName}.zip";

            using (var zipArchive = ZipFile.Open(zipFilename, ZipArchiveMode.Create))
            {
                foreach (var file in Directory.GetFiles(outputFolder))
                {
                    zipArchive.CreateEntryFromFile(file, Path.GetFileName(file));
                }
                
                // Add the new image file to the zip archive with a unique name if it's not already added
                string newImageFilename = $"{inputFilename}_new.png";
                if (File.Exists(newImagePath) && !zipArchive.Entries.Any(e => e.Name == newImageFilename))
                {
                    zipArchive.CreateEntryFromFile(newImagePath, newImageFilename);
                }
            }

            Console.WriteLine($"Output folder and new image zipped and saved as: {zipFilename}");
        }
    }
}